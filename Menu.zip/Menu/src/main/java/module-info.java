module com.example.menu {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.prefs;

    opens com.example.menu to javafx.fxml;
    exports com.example.menu;
}