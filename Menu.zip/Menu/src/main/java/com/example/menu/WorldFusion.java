package com.example.menu;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import javafx.geometry.Pos;
import javafx.scene.control.TextInputDialog;


public class WorldFusion extends Application {
    private final List<Double> prices = new ArrayList<>();
    private Label totalLabel;
    private String customerName; // To hold the customer's name
    private final Preferences prefs = Preferences.userNodeForPackage(WorldFusion.class);
    private boolean hasPromptedForName = false;
    @Override
    public void start(Stage primaryStage) {

        VBox menuLayout = new VBox(10);
        menuLayout.setAlignment(Pos.CENTER); // Center the content in the VBox
        menuLayout.setStyle("-fx-padding: 10;");


        Label sloganLabel = new Label("Dine Globally, Enjoy Locally");
        sloganLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #333;");
        sloganLabel.setAlignment(Pos.TOP_CENTER);
        menuLayout.getChildren().add(sloganLabel);

        Image logoImage = new Image(getClass().getResourceAsStream("/Images/logo.png"));
        ImageView logoView = new ImageView(logoImage);
        logoView.setFitHeight(350);
        logoView.setPreserveRatio(true);
        menuLayout.getChildren().add(logoView);

        totalLabel = new Label("Total: $0.00");
        totalLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        menuLayout.getChildren().add(totalLabel);

        promptForName();
        loadPrices();

        // menu items here...

        addMenuItem(menuLayout, "tacos de birra", 16.99, "/Images/tacos de birra.png");
        addMenuItem(menuLayout, "chicken paprikash", 19.99, "/Images/chicken paprikash.png");
        addMenuItem(menuLayout, "Pho", 19.99, "/Images/Pho.jpg");
        addMenuItem(menuLayout, "Couscous", 24.99, "/Images/Couscous.jpg");
        addMenuItem(menuLayout, "Fattoush Salad", 9.99, "/Images/Fattoush Salad.jpg");
        addMenuItem(menuLayout, "Chicken Sandwich", 3.75, "/Images/chicken_sandwich.png");
        addMenuItem(menuLayout, "Cobb Salad", 7.99, "/Images/cobb_salad.jpg");
        addMenuItem(menuLayout, "Chicken Shawarma", 10.99, "/Images/Chicken Shawarma.jpg");
        addMenuItem(menuLayout, "Chicken nuggets", 7.99, "/Images/Chicken nuggets.jpg");
        addMenuItem(menuLayout, "Biscuit", 7.99, "/Images/Biscuit.jpg");

        Button checkoutButton = new Button("Checkout");
        checkoutButton.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-background-color: #e7100a; -fx-text-fill: white;");
        checkoutButton.setOnAction(e -> {
            if (performCheckout()) {
                savePrices();
                primaryStage.close();
            }
        });
        menuLayout.getChildren().add(checkoutButton);

        Button exitButton = new Button("Exit");
        exitButton.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-background-color: #f10606; -fx-text-fill: white;");
        exitButton.setOnAction(e -> {
            if (promptForName()) {
                savePrices();
                primaryStage.close();
            }
        });
        menuLayout.getChildren().add(exitButton);
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(menuLayout);
        scrollPane.setFitToHeight(true); // Ensure the ScrollPane will fit the height of the content
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED); // Scroll bar appears when needed


        Scene scene = new Scene(scrollPane, 400, 800);
        primaryStage.setTitle("World Fission");
        primaryStage.setScene(scene);
        primaryStage.show();
    }





    private void addMenuItem(VBox layout, String name, double price, String imagePath) {
        Label nameLabel = new Label(name + " - $" + String.format("%.2f", price));
        nameLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Image image = new Image(getClass().getResourceAsStream(imagePath));
        if (image.isError()) {
            throw new RuntimeException("Failed to load image: " + imagePath);
        }

        ImageView imageView = new ImageView(image);
        imageView.setFitHeight(200);
        imageView.setFitWidth(300);
        imageView.setPreserveRatio(true);

        Button addButton = new Button("Add to Order");
        addButton.setOnAction(e -> {
            addToOrder(price);
            System.out.println("Added " + name + " to order.");
        });

        layout.getChildren().addAll(nameLabel, imageView, addButton);
    }
    private boolean promptForName() {
        // If we've already prompted for the name, don't ask again
        if (hasPromptedForName) {
            return true;
        }

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Customer Name");
        dialog.setHeaderText("Please enter your name:");
        dialog.setContentText("Name:");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent() && !result.get().trim().isEmpty()) {
            customerName = result.get(); // Save the customer's name
            hasPromptedForName = true;
            return true;
        } else {
            // If the user doesn't provide a name, we assume they want to cancel the action
            return false;
        }
    }
    private void addToOrder(double price) {
        prices.add(price);
        updateTotal();
    }

    private void updateTotal() {
        double total = prices.stream().mapToDouble(Double::doubleValue).sum();
        totalLabel.setText("Total: $" + String.format("%.2f", total));
    }

    private boolean performCheckout() {
        if (prices.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Checkout");
            alert.setHeaderText(null);
            alert.setContentText("No items in the order.");
            alert.showAndWait();
            return false;
        } else {
            if (!promptForName()) {
                // If the user cancels the name prompt, don't proceed with checkout
                return false;
            }
            Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
            confirmationAlert.setTitle("Confirm Checkout");
            confirmationAlert.setHeaderText("Confirm your Order");
            confirmationAlert.setContentText("Your total is: " + totalLabel.getText() + "\nDo you want to proceed?");

            Optional<ButtonType> result = confirmationAlert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                prices.clear();
                updateTotal();
                Alert thankYouAlert = new Alert(Alert.AlertType.INFORMATION);
                thankYouAlert.setTitle("Thank you");
                thankYouAlert.setHeaderText(null);
                thankYouAlert.setContentText("Thank you for your purchase, " + customerName + "! Your order has been placed.");
                thankYouAlert.showAndWait();
                return true;
            } else {
                return false;
            }
        }
    }
    private void savePrices() {
        try {
            prefs.putDouble("Total", prices.stream().mapToDouble(Double::doubleValue).sum());
            prefs.putInt("ItemCount", prices.size());
            for (int i = 0; i < prices.size(); i++) {
                prefs.putDouble("Item" + i, prices.get(i));
            }
            prefs.flush();  //
        } catch (BackingStoreException e) {
            e.printStackTrace();  // Log the exception or handle it as needed
        }
    }

    private void loadPrices() {
        prices.clear();
        int itemCount = prefs.getInt("ItemCount", 0);
        for (int i = 0; i < itemCount; i++) {
            prices.add(prefs.getDouble("Item" + i, 0));
        }
        updateTotal();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
